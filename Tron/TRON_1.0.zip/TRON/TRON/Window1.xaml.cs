﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TRON
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
            MiniText_nn.Text = "Neptunk kód: HEJMA7\nSzületési dátum: 1998.11.07";
            FoText_nn.Text = "Feladatok:\n\nAlgoritmusfejlsztő\nFőmenü designának megtervezése és kivitelezése\nJátékstruktura leképezése\nGrafikai elemek megtervezése\nKészítők és a források oldal megtervezése és kivitelezése";
            MiniText_dzs.Text = "Neptunk kód: IVWIVA\nSzületési dátum: 1998.08.10";
            FoText_dzs.Text = "Feladatok:\n\nProjektmenedzset és programfejlsztő\nJátéktés megtervezése és kivitelezése\nKülönböző beállítások megtervezése és elkészítése\nProgram rektor";
            MiniText_csk.Text = "Neptunk kód: P45IAO\nSzületési dátum: 1998.06.29";
            FoText_csk.Text = "Feladatok:\n\nCsapatszervező és dokumentáló\nDokumentáció kezelés, tartalmi formai követelmények rögzítése\nSzöveg rektor\nTesztelés\nFejlesztési lehetőségek eszközölése";
        }
    }
}
